(function () {
  // 1) Configurar Firebase Web
  // Reemplaza el siguiente objeto con tu configuración de Firebase (Firebase Console -> Project settings -> Your apps -> Web app)
  const firebaseConfig = {
    apiKey: "AIzaSyA-S07R9O403sMdr6NpNAA-EorCfhm5NfI",
    authDomain: "alfa-206d1.firebaseapp.com",
    databaseURL: "https://alfa-206d1-default-rtdb.firebaseio.com",
    projectId: "alfa-206d1",
    storageBucket: "alfa-206d1.firebasestorage.app",
    messagingSenderId: "601425549469",
    appId: "1:601425549469:web:18d1345fcf06d01b88dc74",
    measurementId: "G-DMKQDL9ERR"
  };

  try {
    firebase.initializeApp(firebaseConfig);
  } catch (e) {
    console.warn("Firebase init warning:", e?.message || e);
  }

  const db = (firebase && firebase.firestore) ? firebase.firestore() : null;

  // 2) Navegación básica
  const screens = Array.from(document.querySelectorAll('.screen'));
  function show(id) {
    screens.forEach(s => s.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
  }
  document.querySelectorAll('[data-go]')?.forEach(btn => btn.addEventListener('click', () => show(`screen-${btn.getAttribute('data-go')}`)));
  document.querySelector('[button][data-nav]');
  document.querySelectorAll('[data-nav]')?.forEach(btn => btn.addEventListener('click', () => {
    const dest = btn.getAttribute('data-nav');
    if (dest === 'home') show('screen-home');
    if (dest === 'menu') show('screen-menu');
    if (dest === 'admin') show('screen-admin-login');
  }));
  show('screen-home');

  const dniCuil = document.getElementById('dniCuil');
  const genero = document.getElementById('genero');
  const calcularBtn = document.getElementById('calcularBtn');
  const resultadoCuil = document.getElementById('resultadoCuil');
  const lockBanner = document.getElementById('lockBanner');

  // 3) Utilidades
  function sanitizeDni(dni) {
    if (!dni) return '';
    return (dni + '').replace(/\D/g, '').slice(0, 8);
  }

  function calculateCuil(dni, gender) {
    dni = sanitizeDni(dni);
    if (dni.length < 7) return 'El DNI debe tener 7 u 8 dígitos.';
    const paddedDni = dni.padStart(8, '0');
    const prefix = gender === 'Masculino' ? '20' : '27';
    const base = prefix + paddedDni;
    const weights = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
    const sum = base.split('').reduce((acc, char, index) => acc + Number(char) * weights[index], 0);
    const remainder = sum % 11;
    const verifier = remainder === 0 ? 0 : (remainder === 1 ? (gender === 'Masculino' ? 9 : 4) : 11 - remainder);
    const finalPrefix = remainder === 1 ? '23' : prefix;
    return `${finalPrefix}-${paddedDni}-${verifier}`;
  }

  // 4) Eventos

  if (calcularBtn) {
    calcularBtn.addEventListener('click', () => {
      resultadoCuil.textContent = calculateCuil(dniCuil.value, genero.value);
    });
  }

  // Estado de venta (consulta Debito/tarjeta/mercadopago)
  const dniVenta = document.getElementById('dniVenta');
  const buscarVentaBtn = document.getElementById('buscarVentaBtn');
  const resultadoVenta = document.getElementById('resultadoVenta');
  if (buscarVentaBtn) {
    buscarVentaBtn.addEventListener('click', async () => {
      const dni = sanitizeDni(dniVenta.value);
      if (!dni) { resultadoVenta.textContent = 'Ingrese DNI válido'; return; }
      if (!db) { resultadoVenta.textContent = 'Firestore no está configurado.'; return; }
      resultadoVenta.textContent = 'Buscando...';
      try {
        const cols = ['Debito', 'tarjeta', 'mercadopago'];
        const results = [];
        for (const col of cols) {
          const snap = await db.collection(col).where('dni', '==', dni).get();
          snap.forEach(d => results.push({ col, data: d.data() }));
        }
        if (results.length === 0) {
          resultadoVenta.textContent = 'No se encontraron ventas para ese DNI.';
        } else {
          resultadoVenta.innerHTML = results.map(r => {
            const aps = Array.isArray(r.data.apartados) ? r.data.apartados.join(', ') : (r.data.apartado || '');
            const dev = r.data.devolucion ? `<br/>Devolución: ${r.data.devolucion}` : '';
            const apt = (r.data.apto === false) ? ' - No apto venta' : '';
            return `${r.col}: ${r.data.vendedorNombre || ''} - ${r.data.importeTotal || ''} - ${r.data.valorCuota || ''}${aps ? ' - ' + aps : ''}${apt}${dev}`;
          }).join('<br/>');
        }
      } catch (e) {
        resultadoVenta.textContent = 'Error: ' + (e?.message || e);
      }
    });
  }

  // Cargar datos clientes (ventas)
  const metodoPago = document.getElementById('metodoPago');
  const pagoCBU = document.getElementById('pagoCBU');
  const pagoTarjeta = document.getElementById('pagoTarjeta');
  const pagoMP = document.getElementById('pagoMP');
  metodoPago?.addEventListener('change', () => {
    const m = metodoPago.value;
    pagoCBU.hidden = m !== 'CBU';
    pagoTarjeta.hidden = m !== 'Tarjeta';
    pagoMP.hidden = m !== 'MercadoPago';
  });
  const estadoCarga = document.getElementById('estadoCarga');
  document.getElementById('guardarCargaBtn')?.addEventListener('click', async () => {
    try {
      if (!db) { estadoCarga.textContent = 'Firestore no está configurado.'; return; }
      const dni = sanitizeDni(document.getElementById('dniCarga').value);
      const nombre = document.getElementById('nombreCarga').value.trim();
      const numeroEquipo = document.getElementById('numeroEquipo').value.trim();
      const cargo = document.getElementById('cargo').value.trim();
      const provincia = document.getElementById('provincia').value.trim();
      const celular = document.getElementById('celular').value.trim();
      const vendedorNombre = document.getElementById('vendedorNombre').value.trim();
      const vendedorCodigo = document.getElementById('vendedorCodigo').value.trim();
      const importeTotal = Number(document.getElementById('importeTotal').value || 0);
      const valorCuota = Number(document.getElementById('valorCuota').value || 0);
      const metodo = metodoPago.value;
      if (!dni || !nombre || !vendedorNombre) { estadoCarga.textContent = 'Complete DNI, Nombre y Vendedor'; return; }
      const comunes = { dni, nombreApellido: nombre, numeroEquipo, cargo, provincia, celular, vendedorNombre, vendedorCodigo, importeTotal, valorCuota, fechaCreacion: Date.now() };
      if (metodo === 'CBU') {
        const cbu = document.getElementById('cbu').value.trim();
        await db.collection('Debito').add({ ...comunes, cbu });
      } else if (metodo === 'Tarjeta') {
        const numeroTarjeta = document.getElementById('numeroTarjeta').value.trim();
        const fechaVencimiento = document.getElementById('fechaVencimiento').value.trim();
        const codigoTarjeta = document.getElementById('codigoTarjeta').value.trim();
        await db.collection('tarjeta').add({ ...comunes, numeroTarjeta, fechaVencimiento, codigoTarjeta });
      } else if (metodo === 'MercadoPago') {
        const fechaVenta = document.getElementById('fechaVenta').value;
        await db.collection('mercadopago').add({ ...comunes, fechaVenta });
      } else if (metodo === 'Cliente Editorial') {
        await db.collection('editorial').add({ ...comunes, editorial: true });
      }
      estadoCarga.textContent = 'Guardado con éxito';
    } catch (e) {
      estadoCarga.textContent = 'Error al guardar: ' + (e?.message || e);
    }
  });

  // PDF ejemplo
  document.getElementById('crearPdfBtn')?.addEventListener('click', () => {
    try {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      doc.text('¡Hola, Mundo!', 20, 20);
      doc.text('Este es un PDF de ejemplo creado desde la web.', 20, 30);
      doc.save('ejemplo.pdf');
      document.getElementById('pdfStatus').textContent = 'PDF creado y descargado.';
    } catch (e) {
      document.getElementById('pdfStatus').textContent = 'Error creando PDF: ' + (e?.message || e);
    }
  });

  // Admin: login y panel
  const adminPasswordInput = document.getElementById('adminPasswordInput');
  const adminLoginBtn = document.getElementById('adminLoginBtn');
  const adminLoginMsg = document.getElementById('adminLoginMsg');
  const adminPanelMsg = document.getElementById('adminPanelMsg');
  const setAdminPassBtn = document.getElementById('setAdminPassBtn');
  const newAdminPass = document.getElementById('newAdminPass');
  const toggleLockBtn = document.getElementById('toggleLockBtn');
  const listarVentasBtn = document.getElementById('listarVentasBtn');
  const crearCsvBtn = document.getElementById('crearCsvBtn');
  const resetDatosBtn = document.getElementById('resetDatosBtn');

  // Observa bloqueo global
  if (db) {
    db.collection('config').doc('app_state').onSnapshot(snap => {
      const locked = !!(snap && snap.data() && snap.data().locked);
      if (lockBanner) lockBanner.hidden = !locked;
    });
  }

  // Admin login básico contra Firestore (contraseña guardada en doc: config/admin)
  adminLoginBtn?.addEventListener('click', async () => {
    try {
      const pass = adminPasswordInput.value;
      const docSnap = await db.collection('config').doc('admin').get();
      const current = docSnap.exists ? docSnap.data().password : 'samuelyolde1234';
      if (pass === current) {
        adminLoginMsg.textContent = 'OK';
        show('screen-admin-panel');
      } else {
        adminLoginMsg.textContent = 'Contraseña incorrecta';
      }
    } catch (e) {
      adminLoginMsg.textContent = 'Error: ' + (e?.message || e);
    }
  });

  // Cambiar contraseña de admin
  setAdminPassBtn?.addEventListener('click', async () => {
    try {
      const newPass = newAdminPass.value;
      if (!newPass || newPass.length < 6) { adminPanelMsg.textContent = 'Mínimo 6 caracteres'; return; }
      await db.collection('config').doc('admin').set({ password: newPass }, { merge: true });
      adminPanelMsg.textContent = 'Contraseña actualizada';
    } catch (e) {
      adminPanelMsg.textContent = 'Error: ' + (e?.message || e);
    }
  });

  // Bloquear/desbloquear app
  toggleLockBtn?.addEventListener('click', async () => {
    try {
      const snap = await db.collection('config').doc('app_state').get();
      const locked = !!(snap.exists && snap.data().locked);
      await db.collection('config').doc('app_state').set({ locked: !locked, updatedAt: new Date() }, { merge: true });
      adminPanelMsg.textContent = (!locked ? 'Aplicación bloqueada' : 'Aplicación desbloqueada');
    } catch (e) {
      adminPanelMsg.textContent = 'Error: ' + (e?.message || e);
    }
  });

  // Listar ventas
  listarVentasBtn?.addEventListener('click', async () => {
    try {
      const out = [];
      for (const col of ['Debito', 'tarjeta', 'mercadopago']) {
        const snap = await db.collection(col).get();
        snap.forEach(d => out.push({ col, ...d.data() }));
      }
      document.getElementById('ventasListado').innerHTML = out.map(r => `${r.col} - ${r.dni || ''} - ${r.vendedorNombre || ''} - ${r.importeTotal || ''}`).join('<br/>');
    } catch (e) {
      document.getElementById('ventasListado').textContent = 'Error: ' + (e?.message || e);
    }
  });

  // Admin: gestionar clientes en tiempo real (igual que AdminClientsScreen)
  const adminClientsContainer = document.getElementById('adminClientsContainer');
  let adminClientsUnsubs = [];
  function renderAdminClients(items) {
    if (!adminClientsContainer) return;
    if (!items || items.length === 0) { adminClientsContainer.textContent = 'Sin registros'; return; }
    adminClientsContainer.innerHTML = '';
    items.forEach(item => {
        const it = item.data;
        const div = document.createElement('div');
        div.className = 'card';
        const nombre = it.nombreApellido || '';
        const dni = it.dni || '';
        const numEquipo = it.numeroEquipo || '';
        const cargo = it.cargo || '';
        const provincia = it.provincia || '';
        const celular = it.celular || '';
        const vendedorNombreItem = it.vendedorNombre || '';
        const vendedorCodigo = it.vendedorCodigo || '';
        const importeTotal = it.importeTotal || '';
        const valorCuota = it.valorCuota || '';
        const cbu = it.cbu || '';
        const numeroTarjeta = it.numeroTarjeta || '';
        const fechaVencimiento = it.fechaVencimiento || '';
        const codigoTarjeta = it.codigoTarjeta || '';
        const fechaVenta = it.fechaVenta || '';
        const apto = !!it.apto;
        const preApartados = Array.isArray(it.apartados)
          ? it.apartados
          : (it.apartado ? [it.apartado] : [item.collection === 'Debito' ? 'CBU' : item.collection === 'tarjeta' ? 'Tarjeta' : 'MercadoPago']);
        const devolucion = it.devolucion || '';
        div.innerHTML = `
          <div style="display:flex;flex-direction:column;gap:6px">
            ${nombre ? `<div><strong>${nombre}</strong></div>` : ''}
            ${dni ? `<div>DNI: ${dni}</div>` : ''}
            ${numEquipo ? `<div>N° Equipo: ${numEquipo}</div>` : ''}
            ${cargo ? `<div>Cargo: ${cargo}</div>` : ''}
            ${provincia ? `<div>Provincia: ${provincia}</div>` : ''}
            ${celular ? `<div>Celular: ${celular}</div>` : ''}
            ${vendedorNombreItem ? `<div>Vendedor: ${vendedorNombreItem}</div>` : ''}
            ${vendedorCodigo ? `<div>Código Vendedor: ${vendedorCodigo}</div>` : ''}
            ${importeTotal ? `<div>Importe Total: ${importeTotal}</div>` : ''}
            ${valorCuota ? `<div>Valor Cuota: ${valorCuota}</div>` : ''}
            ${cbu ? `<div>CBU: ${cbu}</div>` : ''}
            ${numeroTarjeta ? `<div>Tarjeta: ${numeroTarjeta}</div>` : ''}
            ${fechaVencimiento ? `<div>Venc.: ${fechaVencimiento}</div>` : ''}
            ${codigoTarjeta ? `<div>CVV: ${codigoTarjeta}</div>` : ''}
            ${fechaVenta ? `<div>Fecha Venta: ${fechaVenta}</div>` : ''}
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <span>APTO:</span>
              <label><input type="radio" name="apto-${item.id}" value="si" ${apto ? 'checked' : ''}/> Sí</label>
              <label><input type="radio" name="apto-${item.id}" value="no" ${!apto ? 'checked' : ''}/> No</label>
            </div>
            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
              <span>Apartados:</span>
              <label><input type="checkbox" name="apartados-${item.id}" value="CBU" ${preApartados.includes('CBU')?'checked':''}/> CBU</label>
              <label><input type="checkbox" name="apartados-${item.id}" value="Tarjeta" ${preApartados.includes('Tarjeta')?'checked':''}/> Tarjeta</label>
              <label><input type="checkbox" name="apartados-${item.id}" value="MercadoPago" ${preApartados.includes('MercadoPago')?'checked':''}/> Mercado Pago</label>
              <label><input type="checkbox" name="apartados-${item.id}" value="Consultar por editorial" ${preApartados.includes('Consultar por editorial')?'checked':''}/> Consultar por editorial</label>
            </div>
            <div>
              <textarea id="devolucion-${item.id}" rows="3" style="width:100%" placeholder="Devolución del administrador...">${devolucion}</textarea>
            </div>
            <div class="row right"><button class="primary" id="save-${item.id}">Guardar</button></div>
            <div class="result" id="msg-${item.id}"></div>
          </div>
        `;
        adminClientsContainer.appendChild(div);
        const radiosApto = div.querySelectorAll(`input[name="apto-${item.id}"]`);
        const checksApartados = div.querySelectorAll(`input[name="apartados-${item.id}"]`);
        const msg = div.querySelector(`#msg-${item.id}`);
        const devInput = div.querySelector(`#devolucion-${item.id}`);
        div.querySelector(`#save-${item.id}`)?.addEventListener('click', async () => {
          try {
            let aptoSel = true;
            radiosApto.forEach(r => { if (r.checked && r.value==='no') aptoSel = false; });
            const apartadosSel = Array.from(checksApartados).filter(c => c.checked).map(c => c.value);
            const devolucionVal = devInput.value.trim();
            await db.collection(item.collection).doc(item.id).set({ apto: aptoSel, apartados: apartadosSel, devolucion: devolucionVal }, { merge: true });
            msg.textContent = 'Guardado';
          } catch (e) {
            msg.textContent = 'Error: ' + (e?.message || e);
          }
        });
    });
  }
  function subscribeAdminClients() {
    if (!db) { adminClientsContainer.textContent = 'Firestore no configurado'; return; }
    adminClientsContainer.textContent = 'Cargando...';
    const perCol = { Debito: [], tarjeta: [], mercadopago: [], editorial: [] };
    const recompute = () => {
      const merged = [...perCol.Debito, ...perCol.tarjeta, ...perCol.mercadopago, ...perCol.editorial];
      renderAdminClients(merged);
    };
    ['Debito','tarjeta','mercadopago','editorial'].forEach(col => {
      const unsub = db.collection(col).onSnapshot(snap => {
        perCol[col] = snap.docs.map(d => ({ collection: col, id: d.id, data: d.data() || {} }));
        recompute();
      }, err => { adminClientsContainer.textContent = 'Error: ' + (err?.message || err); });
      adminClientsUnsubs.push(unsub);
    });
  }
  function unsubscribeAdminClients() {
    adminClientsUnsubs.forEach(u => { try { u(); } catch(_){} });
    adminClientsUnsubs = [];
  }
  // Suscribirse al entrar y limpiar al salir
  document.querySelector('[data-go="admin-clients"]')?.addEventListener('click', () => {
    show('screen-admin-clients');
    unsubscribeAdminClients();
    subscribeAdminClients();
  });

  // Crear CSV (todos)
  crearCsvBtn?.addEventListener('click', async () => {
    const msg = adminPanelMsg;
    try {
      msg.textContent = 'Creando CSV...';
      const rows = [];
      for (const col of ['Debito','tarjeta','mercadopago','editorial']) {
        const snap = await db.collection(col).get();
        snap.forEach(d => rows.push({ collection: col, ...(d.data() || {}) }));
      }
      const header = ['DNI','NombreApellido','Provincia','Celular','ImporteTotal','ValorCuota','MetodoPago','DatosPago1','DatosPago2','DatosPago3','VendedorNombre'];
      const lines = [ 'sep=,', header.join(',') ];
      // No quotear valores que comienzan con '=' para preservar fórmula de texto
      function q(s){ s = String(s||''); return s.startsWith('=') ? s : '"' + s.replace(/"/g,'""') + '"'; }
      rows.forEach(d => {
        const metodo = d.apartado || (d.cbu ? 'CBU' : (d.numeroTarjeta ? 'Tarjeta' : (d.fechaVenta ? 'MercadoPago' : (d.editorial ? 'Cliente Editorial' : ''))));
        let dp1='',dp2='',dp3='';
        if (metodo==='CBU') dp1 = d.cbu ? `="${String(d.cbu)}"` : '';
        if (metodo==='Tarjeta') { dp1=d.numeroTarjeta||''; dp2=d.fechaVencimiento||''; dp3=d.codigoTarjeta||''; }
        if (metodo==='MercadoPago') dp1=d.fechaVenta||'';
        if (metodo==='Cliente Editorial') { /* sin datos extra */ }
        const arr = [ d.dni, d.nombreApellido, d.provincia, d.celular, d.importeTotal, d.valorCuota, metodo, dp1, dp2, dp3, d.vendedorNombre ].map(q);
        lines.push(arr.join(','));
      });
      const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'clientes.csv'; a.click();
      URL.revokeObjectURL(url);
      msg.textContent = 'CSV generado y descargado.';
    } catch (e) {
      msg.textContent = 'Error creando CSV: ' + (e?.message || e);
    }
  });

  // Resetear datos de clientes (borra Debito, tarjeta y mercadopago) con lotes <= 400
  resetDatosBtn?.addEventListener('click', async () => {
    try {
      adminPanelMsg.textContent = 'Reseteando datos...';
      let totalBorrados = 0;
      for (const col of ['Debito','tarjeta','mercadopago']) {
        const snap = await db.collection(col).get();
        const refs = snap.docs.map(d => d.ref);
        while (refs.length) {
          const chunk = refs.splice(0, 400);
          const batch = db.batch();
          chunk.forEach(ref => batch.delete(ref));
          await batch.commit();
          totalBorrados += chunk.length;
        }
      }
      adminPanelMsg.textContent = `Datos reseteados. Documentos borrados: ${totalBorrados}`;
    } catch (e) {
      adminPanelMsg.textContent = 'Error al resetear: ' + (e?.message || e);
    }
  });
})();


